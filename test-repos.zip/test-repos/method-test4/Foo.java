public class Foo{
	public void methodDeclarationNeverChanged(){
		int b = 2;
		int c = 3;
	}

	public void methodNameChangedOnce1(){
		int b = 2;
		int c = 3;
	}

	public int methodNameAndRetrurnTypeChangeOnceTogether1(){
		int b = 2;
		int c = 3;
		return 1;
	}

	public int methodNameAndRetrurnTypeChangeOnceSeperate1(){
		int a = 1;
		return 1;
	}

	public void methodVisibilityChangedOnce(){
		int a = 1;
	}
	
	private void methodChangedThreeTimes3(){
		int a = 1;
	}
}