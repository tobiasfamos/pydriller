public class Foo{
	public void someFunction(){
		int b = 2;
		int c = 3;
	}

	public void someFunction2(){
		int b = 2;
		int c = 3;
	}

	public void someFunction3(){
		int b = 2;
		int c = 3;
	}
}