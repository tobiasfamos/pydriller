public class Foo{
	public void onlyOnePath(){
		int b = 2;
	}

	public void TwoPathsWithAIf(){
		int b = 2;
		int c = 3;
		if(a == 0){
			return 1;
		}
		return 2;
	}

	public int TwoPathsWithIfElse(){
		int a = 0;
		if(a == 0){
			a = 1;
		}else{
			a = 0;
		}
		return 0;//Comment
	}

	public int twoPathsWithForAndIf(){
		int a = 0;
		for(int i = 0; i <10; i++){
			a++;
		}
		if(a > 10){
			return 1;
		}
		return 0;
	}

	public void fivePathsWithSwitchStatement(){
		int a = 0
		switch(a) {
  		case 1:
    		// code block
   			 break;
  		case 2:
   			 // code block
		    break;
		case 3:
   			 // code block
		    break;
		case 4:
   			 // code block
		    break;    
		case 5:
   			 // code block
		    break;
		default:
			// code block
		} 
	}
	private void succAddThreeIfStatements(){
		int a = 0;
		if(a == 1){
			return 1;
		}
		if(a == 2){
			return 2;
		}
		if( true){
			return 3;
		}
	}
}