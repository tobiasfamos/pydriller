class Arquivo {
  void a() {
   b();
  }

}
