public class Foo{
	public void OneLineCodeOneLineComment(){
		int b = 2;
		//Comment
	}

	public void TwoLinesCodeOneLineComment(){
		int b = 2;
		int c = 3;
		//Comment
	}

	public int CommenAfterEachCodeLine(){
		int b = 2;//Comment
		int c = 3;//Comment
		return 1;//Comment
	}

	public int OneLineCodeFourLinesComment(){
		return 1;
		//1
		//2
		//3
		//4
	}

	public void multiLineComment3LinesOneLineCode(){
		int a = 1;
		/* First LIne
		Second Line
		Third Line */
	}
}